% function to organize DICOM for PET
function [SUV, voxel_size_pet] = DICOM2MHD_PET(inputDir,outDir,savename,saveformat)

cd(inputDir)
files = dir('PE*.dcm');
nfile = length(files);
info = dicominfo(files(1).name);
SIZE_X = double(info.Width); SIZE_Y = double(info.Height);
SUV = zeros(SIZE_X,SIZE_Y,nfile);
z_pet = zeros(1,nfile);
k = 0;
for i = 1 : nfile
    info = dicominfo(files(i).name);
    k = k + 1;
    image = dicomread(info);
    %disp(size(image));
    PET(:,:,k) = image;
    SUV(:,:,k) = info.RescaleSlope * double(image) + info.RescaleIntercept;    % raw dicom image to PET activity
    z_pet(k) = info.SliceLocation;
end
voxel_size_pet = [info.PixelSpacing; info.SliceThickness];
% Re-order images
[tmp, ind] = sort(z_pet, 'ascend');
z_pet = z_pet(ind); SUV = SUV(:,:,ind); PET = PET(:,:,ind);

% convert raw PET data to SUV
half_life = info.RadiopharmaceuticalInformationSequence.Item_1.RadionuclideHalfLife;
total_dose = info.RadiopharmaceuticalInformationSequence.Item_1.RadionuclideTotalDose;  % at injection
scan_time = info.SeriesTime;    % for GE, if post-processed, need to use private data.
scan_t = str2double(scan_time(1:2))*3600 + str2double(scan_time(3:4))*60 + str2double(scan_time(5:6));
measured_time = info.RadiopharmaceuticalInformationSequence.Item_1.RadiopharmaceuticalStartTime;
measured_t = str2double(measured_time(1:2))*3600 + str2double(measured_time(3:4))*60 + str2double(measured_time(5:6));
decay = 2^(-(scan_t-measured_t)/half_life); % Dose Decay Correction Factor
actual_activity = total_dose * decay;   % activity at start of scan
SUV = SUV * info.PatientWeight*1000 / actual_activity; % % converts to SUV Body Weight: units in g/ml

if max(SUV(:)) > 65, disp(max(SUV(:))); end

if saveformat == 'nii'
    cd(inputDir)
    delete('*.nii');
    status=dos([codeDir,'dcm2nii -a n -g n -d y -e n -i n -r n -p n -n y   -o ', outputDir, ' ', inputDir]);
end

if saveformat == 'mhd'
    cd(inputDir)
    delete('*.raw');
    delete('*.mhd');
    ConvertMat2mhd(SUV*1000,outDir,'PET',voxel_size_pet,'uint16');
end

saveData = fullfile(outDir,savename);
save(saveData,'SUV','voxel_size_pet');    

end