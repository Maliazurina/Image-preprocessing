function imageCheck(CT,tumor,saveDir,ID)
% save the figures
h = figure('Visible','off');
TumorVox = sum(tumor,1);  TumorVox = sum(TumorVox,2); TumorVox = TumorVox(:);
[~,idx] = max(TumorVox);
BW = tumor(:,:,idx); [B1,L1]=bwboundaries(BW);

f1=subplot(2,2,1);
imshow(CT(:,:,idx),[]); hold on;
for k=1:length(B1)
	boundary = B1{k};
	plot(boundary(:,2), boundary(:,1),...
		'r-', 'LineWidth', 1)
end

idx = datasample(find(TumorVox),1);
BW = tumor(:,:,idx); [B1,L1]=bwboundaries(BW);
f2=subplot(2,2,2);
imshow(CT(:,:,idx),[]); hold on;
for k=1:length(B1)
	boundary = B1{k};
	plot(boundary(:,2), boundary(:,1),...
		'r-', 'LineWidth', 1)
end

f3 = subplot(2,2,3);
histogram(CT(:));

f4 = subplot(2,2,4);
histogram(CT(logical(tumor)));

tmp = fullfile(saveDir,ID);
cmd = ['saveas(h,''', tmp, '_process'',', '''png'')'];
eval(cmd);
end