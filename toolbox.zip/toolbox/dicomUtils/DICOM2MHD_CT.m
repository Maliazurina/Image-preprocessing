% function to analyze DICOM for CT
function [CT,img_resolution] = DICOM2MHD_CT(inputDir,outDir,savename,saveformat)
codeDir = '..\mricron\';

% cd(inputDir)
% files = dir('CT*');
files = dir(fullfile(inputDir, 'CT*'));
nfile = length(files);
info = dicominfo(fullfile(inputDir, files(1).name));
SIZE_X = double(info.Width); SIZE_Y = double(info.Height);
CT = zeros(SIZE_Y,SIZE_X,nfile);
z_ct = zeros(1,nfile); 
% k = 0;
for i = 1 : nfile
    info = dicominfo(fullfile(inputDir, files(i).name));
    image = dicomread(info);
    CT(:,:,i) = info.RescaleSlope * double(image) + info.RescaleIntercept;    % correct the CT number
    z_ct(i) = info.SliceLocation;
end
%
img_resolution = [info.PixelSpacing; info.SliceThickness]';
[~, ind] = sort(z_ct, 'ascend');
z_ct = z_ct(ind);   
CT = CT(:,:,ind);          % Re-order images

if saveformat == 'nii'
    cd(outDir)
    delete('*.nii');
    status=dos([codeDir,'dcm2nii -a n -g n -d y -e n -i n -r n -p n -n y   -o ', outputDir, ' ', inputDir]);
end

if saveformat == 'mhd'
    cd(outDir)
    delete('*.raw');
    delete('*.mhd');
    ConvertMat2mhd(CT,outDir,'CT',voxel_size_ct,'short');
end

if saveformat == 'mat'
    saveData = fullfile(outDir,savename);
    save(saveData,'CT','img_resolution');
end

if saveformat == 'non'
    disp('CT not saved!')
end

end