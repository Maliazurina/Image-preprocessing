function [contours, gtvIndex] = readRTstructures_name(rtssheader, imgheaders)

%%
xfm = getAffineXfm(imgheaders);

dimmin = [0 0 0 1]';
dimmax = double([imgheaders{1}.Columns-1 imgheaders{1}.Rows-1 length(imgheaders)-1 1])';

template = false([imgheaders{1}.Columns imgheaders{1}.Rows length(imgheaders)]);

ROIContourSequence = fieldnames(rtssheader.ROIContourSequence);
contours = cell(length(ROIContourSequence),1);
%% Loop through contours
for i = 1:length(ROIContourSequence)
  contours{i} = rtssheader.StructureSetROISequence.(ROIContourSequence{i}).ROIName;
end

gtvIndex = 0;
if ~isempty(find(strcmp(contours,'GTV' )))
    gtvIndex = find(strcmp(contours,'GTV' ));
    disp(['GTV name: GTV; Index number is ',num2str(gtvIndex)]);
end

if gtvIndex==0 & ~isempty(find(strcmp(contours,'gtv' )))
    gtvIndex = find(strcmp(contours,'gtv' ));
    disp(['GTV name: gtv; Index number is ',num2str(gtvIndex)]);
end

if gtvIndex==0 & ~isempty(find(strcmp(contours,'GTV Exp' )))
    gtvIndex = find(strcmp(contours,'GTV Exp' ));
    disp(['GTV name: GTV Exp; Index number is ',num2str(gtvIndex)]);
end

if gtvIndex==0 & ~isempty(find(strcmp(contours,'GTV_RUL')))
    gtvIndex = find(strcmp(contours,'GTV_RUL' ));
    disp(['GTV name: GTV_RUL; Index number is ',num2str(gtvIndex)]);
end

if gtvIndex==0 & ~isempty(find(strcmp(contours,'RLL_GTV')))
    gtvIndex = find(strcmp(contours,'RLL_GTV' ));
    disp(['GTV name: RLL_GTV; Index number is ',num2str(gtvIndex)]);
end

if gtvIndex==0 & ~isempty(find(strcmp(contours,'RUL_GTV')))
    gtvIndex = find(strcmp(contours,'RUL_GTV' ));
    disp(['GTV name: RUL_GTV; Index number is ',num2str(gtvIndex)]);
end

if gtvIndex==0 & ~isempty(find(strcmp(contours,'GTV_LUL')))
    gtvIndex = find(strcmp(contours,'GTV_LUL' ));
    disp(['GTV name: GTV_LUL; Index number is ',num2str(gtvIndex)]);
end

if gtvIndex==0 & ~isempty(find(strcmp(contours,'LUL_GTV')))
    gtvIndex = find(strcmp(contours,'LUL_GTV' ));
    disp(['GTV name: LUL_GTV; Index number is ',num2str(gtvIndex)]);
end

if gtvIndex==0 & ~isempty(find(strcmp(contours,'GTV fine cut')))
    gtvIndex = find(strcmp(contours,'GTV fine cut' ));
    disp(['GTV name: GTV fine cut; Index number is ',num2str(gtvIndex)]);
end

if gtvIndex==0 & ~isempty(find(strcmp(contours,'GTV_LLL_Brthhold')))
    gtvIndex = find(strcmp(contours,'GTV_LLL_Brthhold' ));
    disp(['GTV name: GTV_LLL_Brthhold; Index number is ',num2str(gtvIndex)]);
end

if gtvIndex==0 & ~isempty(find(strcmp(contours,'GTV_RLL')))
    gtvIndex = find(strcmp(contours,'GTV_RLL' ));
    disp(['GTV name: GTV_RLL; Index number is ',num2str(gtvIndex)]);
end

if gtvIndex==0 & ~isempty(find(strcmp(contours,'GTV SABR')))
    gtvIndex = find(strcmp(contours,'GTV SABR' ));
    disp(['GTV name: GTV SABR; Index number is ',num2str(gtvIndex)]);
end

if gtvIndex==0 & ~isempty(find(strcmp(contours,'GTV_PRI')))
    gtvIndex = find(strcmp(contours,'GTV_PRI' ));
    disp(['GTV name: GTV_PRI; Index number is ',num2str(gtvIndex)]);
end

if gtvIndex==0 & ~isempty(find(strcmp(contours,'GTV_LLL_INSPBH')))
    gtvIndex = find(strcmp(contours,'GTV_LLL_INSPBH' ));
    disp(['GTV name: GTV_LLL_INSPBH; Index number is ',num2str(gtvIndex)]);
end


end