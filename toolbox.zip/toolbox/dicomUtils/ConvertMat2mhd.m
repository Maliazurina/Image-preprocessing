function ConvertMat2mhd(ImageData,PathName,SaveFileName,ImResolution,DataType)
% 
% write a header file
fid = fopen([PathName,SaveFileName,'.mhd'],'w+');
if length(ImResolution) == 3
    fprintf(fid,['ObjectType = Image\r\nNDims = 3\r\nBinaryData = True\r\nBinaryDataByteOrderMSB = False\r\nElementSpacing = %1.4f %1.4f %1.4f\r\n',...
        'DimSize = %i %i %i\r\nElementType = MET_SHORT\r\nElementDataFile = %s\r\n'],ImResolution,size(ImageData),[SaveFileName,'.raw']);
elseif length(ImResolution) == 2
    fprintf(fid,['ObjectType = Image\r\nNDims = 2\r\nBinaryData = True\r\nBinaryDataByteOrderMSB = False\r\nElementSpacing = %1.4f %1.4f\r\n',...
        'DimSize = %i %i\r\nElementType = MET_SHORT\r\nElementDataFile = %s\r\n'],ImResolution,size(ImageData),[SaveFileName,'.raw']);
end
fclose(fid);
% write the image data
fid = fopen([PathName,SaveFileName,'.raw'],'w+');
fwrite(fid,ImageData,DataType);   % data type
fclose(fid);
% 
end