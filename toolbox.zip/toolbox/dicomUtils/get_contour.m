function [ContourData,ContourReferenceUID] = get_contour(folder_name,folder_CT,saveFolder,varargin)
% Get Contour in the *Eclipse Coordinate System* in mm
% Note [x,y,z] -> [LR, AP, SI]
% Positive: [left, posterior, superior]
%************************* INPUT *************************************%
filesRS = dir([folder_name, '\*.dcm']);
if length(filesRS) < 1
    error('No DICOM-RT for structures!');
end
nargin = 1;
filenameRS = filesRS(1).name;
info = dicominfo(fullfile(folder_name, filenameRS));

%% display the contour names
names = fieldnames(info.StructureSetROISequence);
roiNames = cell(1,length(names)); %count = 0; ContourData = [];
for i = 1 : length(names)
    roiNames{i} = info.StructureSetROISequence.(names{i}).ROIName;
%     if (~isempty(strfind(roiNames{i},'gtv'))) || (~isempty(strfind(roiNames{i},'GTV')))
%         count = count + 1;
%         ContourData{1,count} = roiNames{i};
%     end
    if nargin == 1
        disp([num2str(i), '   ', roiNames{i}]);  
    end
end
roiItems = fieldnames(info.ROIContourSequence); % Item_1, etc.
% return;
%% Now work on contours (PTV etc.)
if isempty(varargin)
    reply3 = input('Enter the index for contours (number only): ', 's');
    ContourId = str2double(reply3);
else
    for i = 1 : length(roiNames)
        %if strcmp(roiNames{i},varargin{1})
        if length(roiNames) > 1
            error([folder_name,' patient has more than 1 GTV! Wrong!'])
        end
        ContourId = i; break
        %end
    end
end
nContour = length(ContourId);
ContourAll = cell(1,nContour);
% ContourName = roiNames(ContourId);

for j = 1 : nContour
    
    roiId = ContourId(j);
    disp(roiNames{roiId});
    names = fieldnames(info.ROIContourSequence.(roiItems{roiId}).ContourSequence);
    nSlice = length(names);     ContourData = cell(1,nSlice);
    
    % The following get the contour data in LINAC coordinate system
    for i = 1 : nSlice
        ContourData{i} = reshape(info.ROIContourSequence.(roiItems{roiId}).ContourSequence.(names{i}).ContourData, 3, []);
        ContourReferenceUID{i} = info.ROIContourSequence.(roiItems{roiId}).ContourSequence.(names{i}).ContourImageSequence.Item_1.ReferencedSOPInstanceUID;
    end
    
    ContourAll{j} = ContourData;    
end

% FOCOS ON GTV/ITV/PTV ONLY
names = fieldnames(info.ROIContourSequence.(roiItems{roiId}).ContourSequence);
nSlice = length(names);     ContourData = cell(1,nSlice);

% The following get the contour data in Eclipse coordinate system
for i = 1 : nSlice
    ContourData{i} = reshape(info.ROIContourSequence.(roiItems{roiId}).ContourSequence.(names{i}).ContourData, 3, []);
end

% offset
Offset(1:2) = -([double(info.Width);double(info.Height)]-1)/2 .* info.PixelSpacing - info.ImagePositionPatient(1:2); Offset(3) = 0;
fprintf('Offset = %1.2f, %1.2f, %1.2f\n',Offset)
ContourDataCT = ContourData;
for count = 1:length(ContourData)
    ContourDataCT{count} = [ContourData{count}(1,:) + Offset(1); ContourData{count}(2,:) + Offset(2); ContourData{count}(3,:) + Offset(3)];
end

z = obtain_z(folder_CT,ContourDataCT);

zcontour = zeros(1,length(ContourDataCT));
for i = 1 : length(ContourDataCT)
    zcontour(i) = ContourData{i}(3,1);
end

slice_ind = z >= min(zcontour) & z <= max(zcontour);
voi = imageData(:,:,slice_ind);   % bounding box along z direction
zvoi = z(slice_ind);    % z location for voi

% get contour mask slice by slice
mask = false(size(CT));
slice_n = ceil(size(CT,3)/2); r1 = ceil(sqrt(length(zvoi))); if r1>2, r = 2; else r = r1; end; c = 3; spcount = 0; nr = 50; [SXvoi,SYvoi,~] = size(voi); ContourCentroid = 0;NPts = 0; points = []; FigNo = 0;
sliceInd = find(slice_ind);
if isempty(CLim), CLim = [min(voi(:)),max(voi(:))]; end
for i = 1 : length(zvoi)
    [~,contour_ind] = min(abs(zvoi(i)-zcontour));
    contour_xy = ContourData{contour_ind}(1:2,:);
    ContourCentroid = ContourCentroid+sum(ContourData{contour_ind},2); NPts = NPts+size(contour_xy,2);
    %     contour_xy = [contour_xy(1,:)-xyo(1);contour_xy(2,:)-xyo(2)];
    contour_grid = [contour_xy(1,:)/voxel_size(1) + SIZE_X/2 + 0.5;
        contour_xy(2,:)/voxel_size(2) + SIZE_Y/2 + 0.5]; % convert physical coordinate to voxel grid coordinate
    spcount = spcount + 1; FigNo = ceil(spcount/(r*c)); MeanContour = round(mean(contour_grid,2)); XRange = [max(1,MeanContour(1)-nr),min(MeanContour(1)+nr,SXvoi)]; YRange = [max(1,MeanContour(2)-nr),min(MeanContour(2)+nr,SYvoi)];
    mask(:,:,i) = poly2mask(contour_grid(1,:),contour_grid(2,:), SIZE_X, SIZE_Y);
    pointsLoc = bwboundaries(mask(:,:,i));
    points = [points; [pointsLoc{1}, zvoi(i)*ones(size(pointsLoc{1},1),1)]];
end

% %% Save contour data.
% filename = 'tumor_gtv.mat';
% save([saveFolder, '/', filename], 'ContourData','ContourReferenceUID');
% % disp([filename, ' saved.']);

end

function [ZVecInterp] = obtain_z(folder_RS,ContourData)
    files = dir([folder_RS, '\*.dcm']);
    nfile = length(files);
    info = dicominfo([folder_RS, files(1).name]);
    SIZE_X = double(info.Width); SIZE_Y = double(info.Height);
    CT = zeros(SIZE_Y,SIZE_X,nfile); 
    z_ct = zeros(1,nfile); k = 0;
    for i = 1 : nfile
        info = dicominfo([folder_RS, files(i).name]);
        image = dicomread(info);
        CT(:,:,i) = info.RescaleSlope * double(image) + info.RescaleIntercept;    % raw dicom image to PET activity
        z_ct(i) = info.SliceLocation;
        SOPInstanceUID{i} = info.SOPInstanceUID;    
    end
% 
    voxel_size_ct = [info.PixelSpacing; info.SliceThickness];
    [~, ind] = sort(z_ct, 'ascend');    
    z_ct = z_ct(ind);   CT = CT(:,:,ind);          % Re-order images
    SOPInstanceUID = SOPInstanceUID(ind);
% 
%     ConvertMat2mhd(CT,folder_RS,'CT-orig',voxel_size_ct,'short');
% 
    XVec = (1:SIZE_X)*voxel_size_ct(1); YVec = (1:SIZE_Y)*voxel_size_ct(2); ZVec = z_ct; ResolVec = voxel_size_ct;
    [XMat,YMat,ZMat] = meshgrid(XVec,YVec,ZVec);
    [XpMat,YpMat,ZpMat] = meshgrid(XVec(1):ResolVec(1):XVec(end),YVec(1):ResolVec(2):YVec(end),ZVec(1):ResolVec(3):ZVec(end));
    ZVecInterp = squeeze(ZpMat(1,1,:))';
    
end



